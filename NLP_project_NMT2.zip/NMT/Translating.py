from transformers import T5Tokenizer, T5ForConditionalGeneration
import pickle
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM

loaded_model = pickle.load(open('models/finalized_model_t5_small', 'rb'))
loaded_model_hilsinki = pickle.load(open("models/finalized_model_hilsinki", 'rb'))
loaded_model_fr_ar = pickle.load(open('models/model_fr_ar', 'rb'))
loaded_model_ar_fr = pickle.load(open('models/model_ar_fr', 'rb'))
loaded_model_en_ar = pickle.load(open('models/model_en_ar', 'rb'))
loaded_model_ar_en = pickle.load(open('models/model_ar_en', 'rb'))

loaded_tokenizer = pickle.load(open('models/saved_tokenizer', 'rb'))
loaded_auttokenizer = pickle.load(open('models/saved_auto_tokenizer', 'rb'))
loaded_auttokenizer_fr_ar = pickle.load(open('models/auto_tokenizer_fr_ar', 'rb'))
loaded_auttokenizer_ar_fr = pickle.load(open('models/auto_tokenizer_ar_fr', 'rb'))
loaded_auttokenizer_en_ar = pickle.load(open('models/auto_tokenizer_en_ar', 'rb'))
loaded_auttokenizer_ar_en = pickle.load(open('models/auto_tokenizer_ar_en', 'rb'))


def trans_En_Fr(input):
    input_ids = loaded_tokenizer("translate English to French: "+input, return_tensors="pt").input_ids
    outputs = loaded_model.generate(input_ids)
    decoded = loaded_tokenizer.decode(outputs[0], skip_special_tokens=True)
    return decoded

def trans_Fr_En(input):
    input_tok = loaded_auttokenizer(input, return_tensors="pt").input_ids
    outputs = loaded_model_hilsinki.generate(input_tok)
    decoded = loaded_auttokenizer.decode(outputs[0], skip_special_tokens=True)
    return decoded

def trans_Fr_Ar(input):
    input_tok = loaded_auttokenizer_fr_ar(input, return_tensors="pt").input_ids
    outputs = loaded_model_fr_ar.generate(input_tok)
    decoded = loaded_auttokenizer_fr_ar.decode(outputs[0], skip_special_tokens=True)
    return decoded

def trans_Ar_Fr(input):
    input_tok = loaded_auttokenizer_ar_fr(input, return_tensors="pt").input_ids
    outputs = loaded_model_ar_fr.generate(input_tok)
    decoded = loaded_auttokenizer_ar_fr.decode(outputs[0], skip_special_tokens=True)
    return decoded

def trans_En_Ar(input):
    input_tok = loaded_auttokenizer_en_ar(input, return_tensors="pt").input_ids
    outputs = loaded_model_en_ar.generate(input_tok)
    decoded = loaded_auttokenizer_en_ar.decode(outputs[0], skip_special_tokens=True)
    return decoded

def trans_Ar_En(input):
    input_tok = loaded_auttokenizer_ar_en(input, return_tensors="pt").input_ids
    outputs = loaded_model_ar_en.generate(input_tok)
    decoded = loaded_auttokenizer_ar_en.decode(outputs[0], skip_special_tokens=True)
    return decoded