from flask import Flask, render_template,request
import Translating

app = Flask(__name__, static_folder='/home/rtm/Documents/pageweb/static', template_folder='templates')

@app.route('/', methods=['GET'])
def index():
	return render_template('index.html')


@app.route('/' , methods=['POST'])
def test():
    in_text = ''
    out_text = ''
    f_lang = ''
    t_lang = '' 

    if request.method == 'POST':
        select = request.form.get('from_lang')
        in_text = select
        select = request.form.get('Sfrom_lang')
        f_lang = select
        select = request.form.get('Sto_lang')
        t_lang = select
        if f_lang == "En" and t_lang == "Fr" : 
            out_text = Translating.trans_En_Fr(in_text)
        if f_lang == "Fr" and t_lang == "En" : 
            out_text = Translating.trans_Fr_En(in_text)
        if f_lang == "En" and t_lang == "Ar" : 
            out_text = Translating.trans_En_Ar(in_text)
        if f_lang == "Ar" and t_lang == "En" : 
            out_text = Translating.trans_Ar_En(in_text)
        if f_lang == "Fr" and t_lang == "Ar" : 
            out_text = Translating.trans_Fr_Ar(in_text)
        if f_lang == "Ar" and t_lang == "Fr" : 
            out_text = Translating.trans_Ar_Fr(in_text)
        
    return render_template('index.html', message0=in_text, message=out_text)

        

app.run() 